<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html><head>
<meta content="text/html; charset=utf-8" http-equiv="content-type"><title>ANONPLUS</title></head>
<body style="color: white; background-color: black;" alink="#00cccc" link="#00cccc" vlink="#00cccc">

<table style="text-align: left; max-width: 1310px;" border="0" cellpadding="2" cellspacing="2">
<tbody>
<tr>
<td style="max-width: 646px; text-align: center; vertical-align: top;">
    <img src="https://i.imgur.com/xFEa0Uq.png" style="max-width:420px" />
</td>
<td style="max-width: 644px; vertical-align: top; text-align: left;">
<br style="font-family: Helvetica,Arial,sans-serif;">
<img src="https://i.imgur.com/OHOZVUf.png" style="max-width:200px" /><br><br>
<br style="font-family: Helvetica,Arial,sans-serif;">

<br><br><small><span style="font-family: Helvetica,Arial,sans-serif;">
<tr><td>
<b>1.</b> We are AnonPlus and this is our manifest.
</td></tr>
<tr><td>
<b>2.</b> 
Any person who wants to defend its freedom of information, freedom of the people and the emancipation of the latter from the bondage of the media and of those who govern us, who we use as a tool to implement its dirty purposes, is already part of AnonPlus.<br>
Every person who has the will to act is welcome.<br>
</td></tr>
<tr><td>
<b>3.</b> AnonPlus has a space to share ideas open to all: <a href="http://webchat.anonplus.org/" target="_blank"><span style="font-family: Helvetica,Arial,sans-serif; font-weight: bold;">webchat.anonplus.org</span></a><br>
</td></tr>
<tr><td>
<b>4.</b> AnonPlus spreads ideas without censorship, creates space to spread directly through mass defacement, news that the media managed for the consumption of who controls us no place, in order to restore dignity to the function of the media;
AnonPlus puts offline sites that actively contribute to the control of the masses from the corrupt, that by manipulating information and opinions create false realities;
AnonPlus not act for personal or political, has no leaders, moves to the interest of the people and to give back to the people's sovereignty;
<br>AnonPlus and is open to any proposal of the people, for the people.
</td></tr>
<tr><td>
<b>5.</b> The day that these objectives will be achieved AnonPlus will cease to exist.
<br>
<br> No war - No religions - No politicals - No financial power - for a Better World
<br><br><br>
WE ARE LEGION<br>
WE DON'T FORGET<br>
WE DON'T FORGIVE<br>
EXPECT US!</small><br>
<br><br>
ANONPLUS<br>
<br>
</td></tr></span></big></big></big>
<big><big><big><span style="font-family: Helvetica,Arial,sans-serif; font-style: italic;"></span></big></big></big></div>
</div>
</td>
</tr>
</tbody>
</table>
</body></html>